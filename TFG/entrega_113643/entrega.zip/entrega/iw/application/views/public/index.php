<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
$this->load->view('public/includes/cabecera');
?>


<div class="contact-agile">
    <div class="faq">
        <?php echo $output; ?>
    </div>
</div>
    
<?php
$this->load->view('public/includes/pie');
?>