</div>
<!-- /#page-wrapper -->

<!-- /#wrapper -->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
</body>

</html>